<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'backup' => array (
  'slugs' => 
  array (
    0 => 'backup',
  ),
  'paths' => 
  array (
    0 => '/admin/backup',
    1 => '/admin/public/backup',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'backup_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'backup',
  ),
  'folder' => 'Backup',
),
];
