# Cum creezi / clonezi un modul (START)

## Cel mai clar drum (recomandat)

Nu redenumi manual. Pe PC-ul cu proiectul:

```bash
php admin/generate_module_v2.php Note --workspace=company
```

Apoi editezi doar:
- `src/NoteService.php` — logica
- `pages/index.php` — ecranul
- `api/note_endpoint.php` — API

Ghid complet în proiect: `admin/modules/START_HERE.md`

## Dacă ai doar acest ZIP (fără generator)

1. Dezarhivează ZIP-ul (trebuie să vezi `module.json` imediat).
2. Redenumește folderul + `id` în `module.json` + namespace în `src/`.
3. Actualizează `nav` / `provides.slugs` / `provides.paths` / `api_scripts`.
4. Copiază în `admin/modules/{NumeStudly}/` SAU Instalează ZIP din Setări → Module.
5. Activează → deschide `/admin/{slug}`.

## Structură

```
{id}/
  module.json
  src/XxxModule.php + XxxService.php
  pages/index.php
  assets/
  api/
  migrations/   (opțional)
  HOW_TO_CLONE.md
```

Checklist: `admin/modules/CHECKLIST_LANSARE.md`