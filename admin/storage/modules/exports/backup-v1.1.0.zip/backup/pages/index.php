<?php

declare(strict_types=1);

$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/backup/backup.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}
echo '<div class="box p-6"><p>Backup — template legacy lipsă.</p></div>';
