<?php

declare(strict_types=1);

namespace Besoiu\Modules\Backup;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/** Entry MVP — Backup se conectează la CORE aici. */
final class BackupModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }
        $context->registry();
    }
}
