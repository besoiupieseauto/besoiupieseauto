<?php

declare(strict_types=1);

namespace Besoiu\Modules\Backup;

/** Serviciu hub al modulului Backup (logică în pachet). */
final class BackupHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        return [
            'module' => 'backup',
            'name' => 'Backup',
            'version' => '1.1.0',
            'ok' => true,
            'package' => ['src' => true, 'pages' => true, 'assets' => true, 'api' => true],
            'features' => array (
  0 => 
  array (
    'id' => 'backup',
    'label' => 'Backup BD',
    'href' => '/admin/backup',
    'desc' => 'Export / restaurare backup',
  ),
),
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf('%s v%s — %d zone · pachet MVP OK', $d['name'], $d['version'], count($d['features']));
    }
}
