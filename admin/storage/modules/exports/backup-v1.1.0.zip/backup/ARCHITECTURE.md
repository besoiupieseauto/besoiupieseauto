# Backup — mini-MVP în pachet

```
modules/Backup/
  module.json
  src/BackupModule.php
  src/BackupHubService.php
  pages/          ← hub + bridge-uri UI
  assets/
  api/
```

CORE rămâne separat. Acest folder = feature ca plugin.