<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'success' => true,
    'module' => 'backup',
    'endpoint' => 'backup_endpoint.php',
    'message' => 'Stub din pachet. Producție: /admin/public/api/backup_endpoint.php',
], JSON_UNESCAPED_UNICODE);
