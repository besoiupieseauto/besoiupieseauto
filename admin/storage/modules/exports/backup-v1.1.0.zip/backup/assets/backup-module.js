(function () {
  var btn = document.getElementById('backup-mod-ping');
  var out = document.getElementById('backup-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Backup/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
