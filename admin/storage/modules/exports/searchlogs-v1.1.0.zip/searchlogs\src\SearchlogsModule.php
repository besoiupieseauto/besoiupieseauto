<?php

declare(strict_types=1);

namespace Besoiu\Modules\Searchlogs;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/** Entry MVP — Search Logs se conectează la CORE aici. */
final class SearchlogsModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }
        $context->registry();
    }
}
