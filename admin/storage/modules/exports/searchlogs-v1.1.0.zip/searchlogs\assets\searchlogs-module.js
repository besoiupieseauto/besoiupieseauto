(function () {
  var btn = document.getElementById('searchlogs-mod-ping');
  var out = document.getElementById('searchlogs-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Searchlogs/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
