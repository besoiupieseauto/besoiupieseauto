<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'success' => true,
    'module' => 'searchlogs',
    'endpoint' => 'search_logs_endpoint.php',
    'message' => 'Stub din pachet. Producție: /admin/public/api/search_logs_endpoint.php',
], JSON_UNESCAPED_UNICODE);
