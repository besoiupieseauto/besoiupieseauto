<?php

declare(strict_types=1);

namespace Besoiu\Modules\Searchlogs;

/** Serviciu hub al modulului Search Logs (logică în pachet). */
final class SearchlogsHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        return [
            'module' => 'searchlogs',
            'name' => 'Search Logs',
            'version' => '1.1.0',
            'ok' => true,
            'package' => ['src' => true, 'pages' => true, 'assets' => true, 'api' => true],
            'features' => array (
  0 => 
  array (
    'id' => 'search-logs',
    'label' => 'Search logs',
    'href' => '/admin/search-logs',
    'desc' => 'VIN/OEM căutate, negăsite',
  ),
),
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf('%s v%s — %d zone · pachet MVP OK', $d['name'], $d['version'], count($d['features']));
    }
}
