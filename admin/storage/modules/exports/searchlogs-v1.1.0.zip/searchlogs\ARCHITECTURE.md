# Search Logs — mini-MVP în pachet

```
modules/Searchlogs/
  module.json
  src/SearchlogsModule.php
  src/SearchlogsHubService.php
  pages/          ← hub + bridge-uri UI
  assets/
  api/
```

CORE rămâne separat. Acest folder = feature ca plugin.