<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'searchlogs' => array (
  'slugs' => 
  array (
    0 => 'searchlogs-system',
    1 => 'searchlogs',
    2 => 'search-logs',
  ),
  'paths' => 
  array (
    0 => '/admin/searchlogs-system',
    1 => '/admin/public/searchlogs-system',
    2 => '/admin/searchlogs',
    3 => '/admin/public/searchlogs',
    4 => '/admin/search-logs',
    5 => '/admin/public/search-logs',
    6 => '/admin/crudsearchlogs',
    7 => '/admin/public/crudsearchlogs',
  ),
  'crud_key' => 'SearchLogsCrud',
  'api_scripts' => 
  array (
    0 => 'search_logs_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'searchlogs-system',
    1 => 'search-logs',
    2 => 'searchlogs',
  ),
  'folder' => 'Searchlogs',
),
];
