<?php

declare(strict_types=1);

$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/searchlogs/searchlogs.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}
echo '<div class="box p-6"><p>Search Logs / search-logs — template legacy lipsă. Hub: <a href="/admin/searchlogs-system">/admin/searchlogs-system</a></p></div>';
