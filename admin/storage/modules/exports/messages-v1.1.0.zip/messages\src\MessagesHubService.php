<?php

declare(strict_types=1);

namespace Besoiu\Modules\Messages;

/** Serviciu hub al modulului Messages (logică în pachet). */
final class MessagesHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        return [
            'module' => 'messages',
            'name' => 'Messages',
            'version' => '1.1.0',
            'ok' => true,
            'package' => ['src' => true, 'pages' => true, 'assets' => true, 'api' => true],
            'features' => array (
  0 => 
  array (
    'id' => 'messages',
    'label' => 'Mesaje',
    'href' => '/admin/messages',
    'desc' => 'Inbox / mesaje admin',
  ),
),
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf('%s v%s — %d zone · pachet MVP OK', $d['name'], $d['version'], count($d['features']));
    }
}
