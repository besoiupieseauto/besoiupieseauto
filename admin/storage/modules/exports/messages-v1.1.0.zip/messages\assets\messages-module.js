(function () {
  var btn = document.getElementById('messages-mod-ping');
  var out = document.getElementById('messages-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Messages/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
