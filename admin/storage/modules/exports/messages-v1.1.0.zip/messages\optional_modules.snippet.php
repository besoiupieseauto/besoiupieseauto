<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'messages' => array (
  'slugs' => 
  array (
    0 => 'messages-system',
    1 => 'messages',
  ),
  'paths' => 
  array (
    0 => '/admin/messages-system',
    1 => '/admin/public/messages-system',
    2 => '/admin/messages',
    3 => '/admin/public/messages',
    4 => '/admin/crudmessages',
    5 => '/admin/public/crudmessages',
  ),
  'crud_key' => 'Messages',
  'api_scripts' => 
  array (
    0 => 'messages_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'messages-system',
    1 => 'messages',
  ),
  'folder' => 'Messages',
),
];
