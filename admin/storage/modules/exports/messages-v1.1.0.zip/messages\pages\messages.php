<?php

declare(strict_types=1);

$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/messages/messages.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}
echo '<div class="box p-6"><p>Messages / messages — template legacy lipsă. Hub: <a href="/admin/messages-system">/admin/messages-system</a></p></div>';
