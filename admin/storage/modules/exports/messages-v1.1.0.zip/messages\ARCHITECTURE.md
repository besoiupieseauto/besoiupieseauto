# Messages — mini-MVP în pachet

```
modules/Messages/
  module.json
  src/MessagesModule.php
  src/MessagesHubService.php
  pages/          ← hub + bridge-uri UI
  assets/
  api/
```

CORE rămâne separat. Acest folder = feature ca plugin.