<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'searchlogs' => array (
  'slugs' => 
  array (
    0 => 'search-logs',
    1 => 'searchlogs',
  ),
  'paths' => 
  array (
    0 => '/admin/search-logs',
    1 => '/admin/public/search-logs',
    2 => '/admin/searchlogs',
    3 => '/admin/crudsearchlogs',
    4 => '/admin/public/searchlogs',
    5 => '/admin/public/crudsearchlogs',
  ),
  'crud_key' => 'SearchLogsCrud',
  'api_scripts' => 
  array (
    0 => 'search_logs_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'searchlogs',
    1 => 'search-logs',
  ),
  'folder' => 'Searchlogs',
),
];
