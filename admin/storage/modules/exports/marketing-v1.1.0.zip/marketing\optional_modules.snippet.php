<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'marketing' => array (
  'slugs' => 
  array (
    0 => 'marketing-system',
    1 => 'marketing',
    2 => 'marketing-indicators',
    3 => 'marketing-actions',
    4 => 'marketing-content',
    5 => 'marketing-calendar',
    6 => 'marketing-paid',
    7 => 'marketing-studio',
    8 => 'planner',
  ),
  'paths' => 
  array (
    0 => '/admin/marketing-system',
    1 => '/admin/public/marketing-system',
    2 => '/admin/marketing',
    3 => '/admin/public/marketing',
    4 => '/admin/marketing-indicators',
    5 => '/admin/public/marketing-indicators',
    6 => '/admin/marketing-actions',
    7 => '/admin/public/marketing-actions',
    8 => '/admin/marketing-content',
    9 => '/admin/public/marketing-content',
    10 => '/admin/marketing-calendar',
    11 => '/admin/public/marketing-calendar',
    12 => '/admin/marketing-paid',
    13 => '/admin/public/marketing-paid',
    14 => '/admin/marketing-studio',
    15 => '/admin/public/marketing-studio',
    16 => '/admin/planner',
    17 => '/admin/public/planner',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'marketing_hub_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'marketing-system',
    1 => 'marketing',
    2 => 'planner',
    3 => 'marketing-studio',
  ),
  'folder' => 'Marketing',
),
];
