<?php

declare(strict_types=1);

$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/marketing/content.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}
echo '<div class="box p-6"><p>Marketing / marketing-content — template legacy lipsă. Hub: <a href="/admin/marketing-system">/admin/marketing-system</a></p></div>';
