<?php

declare(strict_types=1);

namespace Besoiu\Modules\Marketing;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/** Entry MVP — Marketing se conectează la CORE aici. */
final class MarketingModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }
        $context->registry();
    }
}
