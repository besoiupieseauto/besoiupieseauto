<?php

declare(strict_types=1);

namespace Besoiu\Modules\Marketing;

/** Serviciu hub al modulului Marketing (logică în pachet). */
final class MarketingHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        return [
            'module' => 'marketing',
            'name' => 'Marketing',
            'version' => '1.1.0',
            'ok' => true,
            'package' => ['src' => true, 'pages' => true, 'assets' => true, 'api' => true],
            'features' => array (
  0 => 
  array (
    'id' => 'marketing',
    'label' => 'Hub marketing',
    'href' => '/admin/marketing',
    'desc' => 'Panou marketing',
  ),
  1 => 
  array (
    'id' => 'planner',
    'label' => 'Planner',
    'href' => '/admin/planner',
    'desc' => 'Planificare conținut',
  ),
  2 => 
  array (
    'id' => 'marketing-studio',
    'label' => 'Studio',
    'href' => '/admin/marketing-studio',
    'desc' => 'Studio creativ',
  ),
),
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf('%s v%s — %d zone · pachet MVP OK', $d['name'], $d['version'], count($d['features']));
    }
}
