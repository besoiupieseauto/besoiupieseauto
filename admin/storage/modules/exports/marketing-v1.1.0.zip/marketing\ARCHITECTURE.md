# Marketing — mini-MVP în pachet

```
modules/Marketing/
  module.json
  src/MarketingModule.php
  src/MarketingHubService.php
  pages/          ← hub + bridge-uri UI
  assets/
  api/
```

CORE rămâne separat. Acest folder = feature ca plugin.