(function () {
  var btn = document.getElementById('marketing-mod-ping');
  var out = document.getElementById('marketing-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Marketing/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
