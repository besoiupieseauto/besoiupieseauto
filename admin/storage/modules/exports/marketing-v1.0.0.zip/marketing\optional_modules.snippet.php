<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'marketing' => array (
  'slugs' => 
  array (
    0 => 'marketing',
    1 => 'planner',
    2 => 'marketing-indicators',
    3 => 'marketing-actions',
    4 => 'marketing-content',
    5 => 'marketing-calendar',
    6 => 'marketing-paid',
    7 => 'marketing-studio',
  ),
  'paths' => 
  array (
    0 => '/admin/marketing',
    1 => '/admin/public/marketing',
    2 => '/admin/planner',
    3 => '/admin/public/planner',
    4 => '/admin/marketing-indicators',
    5 => '/admin/marketing-actions',
    6 => '/admin/marketing-content',
    7 => '/admin/marketing-calendar',
    8 => '/admin/marketing-paid',
    9 => '/admin/marketing-studio',
    10 => '/admin/public/marketing-indicators',
    11 => '/admin/public/marketing-actions',
    12 => '/admin/public/marketing-content',
    13 => '/admin/public/marketing-calendar',
    14 => '/admin/public/marketing-paid',
    15 => '/admin/public/marketing-studio',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'marketing_hub_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'marketing',
    1 => 'marketing-indicators',
    2 => 'marketing-actions',
    3 => 'marketing-content',
    4 => 'marketing-calendar',
    5 => 'marketing-paid',
    6 => 'marketing-studio',
    7 => 'planner',
  ),
  'folder' => 'Marketing',
),
];
