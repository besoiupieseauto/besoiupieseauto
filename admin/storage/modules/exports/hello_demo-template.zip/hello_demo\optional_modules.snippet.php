<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'hello_demo' => array (
  'slugs' => 
  array (
    0 => 'hello-demo',
  ),
  'paths' => 
  array (
    0 => '/admin/hello-demo',
    1 => '/admin/public/hello-demo',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
  ),
  'quick_actions' => 
  array (
  ),
  'folder' => NULL,
),
];
