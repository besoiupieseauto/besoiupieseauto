<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'import' => array (
  'slugs' => 
  array (
    0 => 'import',
    1 => 'importreview',
    2 => 'importproduse',
  ),
  'paths' => 
  array (
    0 => '/admin/import',
    1 => '/admin/importreview',
    2 => '/admin/importproduse',
    3 => '/admin/public/import',
    4 => '/admin/public/importreview',
    5 => '/admin/public/importproduse',
    6 => '/admin/public/bovsoft-import',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'import_endpoint.php',
    1 => 'import_action_endpoint.php',
    2 => 'supplier_sync_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'import',
    1 => 'importreview',
  ),
  'folder' => 'Import',
),
];
