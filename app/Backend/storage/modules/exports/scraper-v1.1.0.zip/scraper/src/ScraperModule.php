<?php

declare(strict_types=1);

namespace Besoiu\Modules\Scraper;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/** Entry MVP — Scraping se conectează la CORE aici. */
final class ScraperModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }
        $context->registry();
    }
}
