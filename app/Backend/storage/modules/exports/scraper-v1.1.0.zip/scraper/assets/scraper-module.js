(function () {
  var btn = document.getElementById('scraper-mod-ping');
  var out = document.getElementById('scraper-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Scraper/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
