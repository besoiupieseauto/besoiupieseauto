# Scraping — mini-MVP în pachet

```
modules/Scraper/
  module.json
  src/ScraperModule.php
  src/ScraperHubService.php
  pages/          ← hub + bridge-uri UI
  assets/
  api/
```

CORE rămâne separat. Acest folder = feature ca plugin.