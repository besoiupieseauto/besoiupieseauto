# Marketplace — mini-MVP în pachet

```
modules/Marketplace/
  module.json
  src/MarketplaceModule.php
  src/MarketplaceHubService.php
  pages/          ← hub + bridge-uri UI
  assets/
  api/
```

CORE rămâne separat. Acest folder = feature ca plugin.