(function () {
  var btn = document.getElementById('marketplace-mod-ping');
  var out = document.getElementById('marketplace-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Marketplace/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
