<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'marketplace' => array (
  'slugs' => 
  array (
    0 => 'marketplace-system',
    1 => 'marketplace',
    2 => 'marketplace-pieseauto',
    3 => 'marketplace-baselinker',
  ),
  'paths' => 
  array (
    0 => '/admin/marketplace-system',
    1 => '/admin/public/marketplace-system',
    2 => '/admin/marketplace',
    3 => '/admin/public/marketplace',
    4 => '/admin/marketplace-pieseauto',
    5 => '/admin/public/marketplace-pieseauto',
    6 => '/admin/marketplace-baselinker',
    7 => '/admin/public/marketplace-baselinker',
    8 => '/admin/crudmarketplace',
    9 => '/admin/public/crudmarketplace',
  ),
  'crud_key' => 'Marketplace',
  'api_scripts' => 
  array (
    0 => 'marketplace_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'marketplace-system',
    1 => 'marketplace',
    2 => 'marketplace-pieseauto',
    3 => 'marketplace-baselinker',
  ),
  'folder' => 'Marketplace',
),
];
