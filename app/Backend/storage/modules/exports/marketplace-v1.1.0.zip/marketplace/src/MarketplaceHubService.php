<?php

declare(strict_types=1);

namespace Besoiu\Modules\Marketplace;

/** Serviciu hub al modulului Marketplace (logică în pachet). */
final class MarketplaceHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        return [
            'module' => 'marketplace',
            'name' => 'Marketplace',
            'version' => '1.1.0',
            'ok' => true,
            'package' => ['src' => true, 'pages' => true, 'assets' => true, 'api' => true],
            'features' => array (
  0 => 
  array (
    'id' => 'marketplace',
    'label' => 'Marketplace',
    'href' => '/admin/marketplace',
    'desc' => 'Hub marketplace',
  ),
  1 => 
  array (
    'id' => 'marketplace-pieseauto',
    'label' => 'PieseAuto',
    'href' => '/admin/marketplace-pieseauto',
    'desc' => 'Canal PieseAuto.ro',
  ),
  2 => 
  array (
    'id' => 'marketplace-baselinker',
    'label' => 'BaseLinker',
    'href' => '/admin/marketplace-baselinker',
    'desc' => 'Canal BaseLinker',
  ),
),
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf('%s v%s — %d zone · pachet MVP OK', $d['name'], $d['version'], count($d['features']));
    }
}
