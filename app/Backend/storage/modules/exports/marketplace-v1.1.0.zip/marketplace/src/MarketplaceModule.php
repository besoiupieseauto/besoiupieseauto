<?php

declare(strict_types=1);

namespace Besoiu\Modules\Marketplace;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/** Entry MVP — Marketplace se conectează la CORE aici. */
final class MarketplaceModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }
        $context->registry();
    }
}
