<?php

declare(strict_types=1);

use Besoiu\Modules\Marketplace\MarketplaceHubService;

$hub = new MarketplaceHubService();
$data = $hub->dashboard();
$css = '/admin/modules/Marketplace/assets/marketplace-module.css';
$js = '/admin/modules/Marketplace/assets/marketplace-module.js';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($css, ENT_QUOTES, 'UTF-8') ?>">
<div class="box p-6 marketplace-mod" style="max-width:960px">
    <header class="mb-4">
        <h1 class="text-xl font-semibold"><?= htmlspecialchars((string) $data['name'], ENT_QUOTES, 'UTF-8') ?></h1>
        <p class="text-sm opacity-80 mt-1"><?= htmlspecialchars($hub->healthLine(), ENT_QUOTES, 'UTF-8') ?></p>
    </header>
    <div class="marketplace-mod__grid">
        <?php foreach ($data['features'] as $f): ?>
            <a class="marketplace-mod__card" href="<?= htmlspecialchars((string) $f['href'], ENT_QUOTES, 'UTF-8') ?>">
                <strong><?= htmlspecialchars((string) $f['label'], ENT_QUOTES, 'UTF-8') ?></strong>
                <span><?= htmlspecialchars((string) $f['desc'], ENT_QUOTES, 'UTF-8') ?></span>
            </a>
        <?php endforeach; ?>
    </div>
    <p class="text-xs opacity-70 mt-4">Pachet: <code>modules/Marketplace/</code></p>
    <button type="button" id="marketplace-mod-ping" class="box rounded-md border bg-primary px-4 py-2 text-sm text-white mt-3">Test assets JS</button>
    <p id="marketplace-mod-out" class="text-sm mt-2 opacity-70"></p>
</div>
<script src="<?= htmlspecialchars($js, ENT_QUOTES, 'UTF-8') ?>"></script>
