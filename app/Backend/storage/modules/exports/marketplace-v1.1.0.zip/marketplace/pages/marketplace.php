<?php

declare(strict_types=1);

$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/marketplace/marketplace.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}
echo '<div class="box p-6"><p>Marketplace / marketplace — template legacy lipsă. Hub: <a href="/admin/marketplace-system">/admin/marketplace-system</a></p></div>';
