<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'blog' => array (
  'slugs' => 
  array (
    0 => 'blog',
    1 => 'addblog',
    2 => 'editblog',
  ),
  'paths' => 
  array (
    0 => '/admin/blog',
    1 => '/admin/public/blog',
    2 => '/admin/addblog',
    3 => '/admin/editblog',
    4 => '/admin/crudblog',
    5 => '/admin/public/addblog',
    6 => '/admin/public/editblog',
    7 => '/admin/public/crudblog',
  ),
  'crud_key' => 'Blog',
  'api_scripts' => 
  array (
  ),
  'quick_actions' => 
  array (
    0 => 'blog',
  ),
  'folder' => 'Blog',
),
];
