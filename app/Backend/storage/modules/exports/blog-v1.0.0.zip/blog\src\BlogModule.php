<?php

declare(strict_types=1);

namespace Besoiu\Modules\Blog;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/**
 * Pilot modul opțional Blog (Faza 3 — unplug).
 *
 * Codul Controllers/Services/Templates rămâne în src/ (legacy path).
 * Unplug = ModuleGate + optional_modules.php:
 * - disable în state.json SAU ștergi admin/modules/Blog/
 * → nav, rute bootstrap/DB, CRUD Blog blocate; CORE rămâne viu.
 */
final class BlogModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        // Marker pentru metric providers / viitor CrudModuleFactory::register
        $context->registry(); // touch — modul activ în registry
    }
}
