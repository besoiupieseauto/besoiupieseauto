(function () {
  var btn = document.getElementById('blog-mod-ping');
  var out = document.getElementById('blog-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Blog/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
