<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'blog' => array (
  'slugs' => 
  array (
    0 => 'blog-system',
    1 => 'blog',
    2 => 'addblog',
    3 => 'editblog',
  ),
  'paths' => 
  array (
    0 => '/admin/blog-system',
    1 => '/admin/public/blog-system',
    2 => '/admin/blog',
    3 => '/admin/public/blog',
    4 => '/admin/addblog',
    5 => '/admin/public/addblog',
    6 => '/admin/editblog',
    7 => '/admin/public/editblog',
    8 => '/admin/crudblog',
    9 => '/admin/public/crudblog',
  ),
  'crud_key' => 'Blog',
  'api_scripts' => 
  array (
  ),
  'quick_actions' => 
  array (
    0 => 'blog-system',
    1 => 'blog',
    2 => 'addblog',
  ),
  'folder' => 'Blog',
),
];
