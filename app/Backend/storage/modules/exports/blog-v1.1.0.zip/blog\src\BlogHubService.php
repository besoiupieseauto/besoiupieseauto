<?php

declare(strict_types=1);

namespace Besoiu\Modules\Blog;

/** Serviciu hub al modulului Blog (logică în pachet). */
final class BlogHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        return [
            'module' => 'blog',
            'name' => 'Blog',
            'version' => '1.1.0',
            'ok' => true,
            'package' => ['src' => true, 'pages' => true, 'assets' => true, 'api' => true],
            'features' => array (
  0 => 
  array (
    'id' => 'blog',
    'label' => 'Articole',
    'href' => '/admin/blog',
    'desc' => 'Listă articole blog',
  ),
  1 => 
  array (
    'id' => 'addblog',
    'label' => 'Articol nou',
    'href' => '/admin/addblog',
    'desc' => 'Creare articol',
  ),
),
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf('%s v%s — %d zone · pachet MVP OK', $d['name'], $d['version'], count($d['features']));
    }
}
