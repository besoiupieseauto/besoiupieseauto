<?php

declare(strict_types=1);

$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/blog/addblog.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}
echo '<div class="box p-6"><p>Blog / addblog — template legacy lipsă. Hub: <a href="/admin/blog-system">/admin/blog-system</a></p></div>';
