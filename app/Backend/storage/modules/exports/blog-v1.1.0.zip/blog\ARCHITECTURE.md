# Blog — mini-MVP în pachet

```
modules/Blog/
  module.json
  src/BlogModule.php
  src/BlogHubService.php
  pages/          ← hub + bridge-uri UI
  assets/
  api/
```

CORE rămâne separat. Acest folder = feature ca plugin.