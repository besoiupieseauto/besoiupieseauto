# Cum clonezi acest modul (arhitectură MVP)

Un modul = mini-MVP separat care se conectează la CORE (auth, produse, comenzi…).

## Structură țintă

```
{id}/
  module.json
  src/                 ← clase Besoiu\Modules\{StudlyId}\
    XxxModule.php      ← entry (boot)
    XxxService.php
  pages/               ← UI (prioritate față de Templates legacy)
    index.php
  assets/              ← CSS/JS proprii
  api/                 ← endpoint-uri (copiate în public/api la deploy)
  migrations/
  HOW_TO_CLONE.md
```

## Pași

1. Dezarhivează ZIP-ul.
2. Redenumește folderul + `id` în `module.json` + namespace în `src/`.
3. Actualizează `nav` / `provides.slugs` / `provides.paths`.
4. **Builtin:** mută în `admin/modules/{StudlyId}/` (provides din manifest e suficient).
5. **Extern:** ZIP → Setări → Module → Instalează.
6. Smoke: Activează → pagină din `pages/`; Oprește → 0 rute; CORE OK.

Vezi: `admin/modules/_examples/mvp_kit/ARCHITECTURE.md` și `PACKAGING.md`.