(function () {
  const btn = document.getElementById('mvp-kit-ping');
  const out = document.getElementById('mvp-kit-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/…/assets/mvp-kit.js — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
