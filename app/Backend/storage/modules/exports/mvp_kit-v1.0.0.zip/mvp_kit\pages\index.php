<?php

declare(strict_types=1);

/**
 * Pagină UI a modulului — trăiește în modules/{Folder}/pages/, NU în Templates/.
 * AdminPageResolver prioritizează acest folder când modulul e activ.
 *
 * Variabile layout (din Templates.php): $this, session, etc. — ca orice pagină admin.
 */

use Besoiu\Modules\MvpKit\MvpKitService;

$service = new MvpKitService();
$status = $service->status();
$cssUrl = '/admin/modules/MvpKit/assets/mvp-kit.css';
$jsUrl = '/admin/modules/MvpKit/assets/mvp-kit.js';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($cssUrl, ENT_QUOTES, 'UTF-8') ?>">

<div class="box p-6 mvp-kit" style="max-width:820px">
    <h1 class="text-xl font-semibold mb-2">MVP Kit</h1>
    <p class="text-sm opacity-80 mb-4">
        Acesta este un <strong>modul real</strong>: clase + pagină + CSS/JS + API în folderul modulului.
        CORE (produse, comenzi, auth) rămâne separat — modulul doar se conectează.
    </p>

    <div class="mvp-kit__card mb-4">
        <h2 class="text-sm font-semibold mb-2">Status serviciu (din src/)</h2>
        <pre class="text-xs opacity-80 overflow-auto"><?= htmlspecialchars(json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') ?></pre>
    </div>

    <ul class="text-sm list-disc pl-5 space-y-1 opacity-80 mb-4">
        <li><code>module.json</code> — contract (id, nav, provides)</li>
        <li><code>src/MvpKitModule.php</code> — entry + boot</li>
        <li><code>src/MvpKitService.php</code> — logică business</li>
        <li><code>pages/index.php</code> — UI (acest fișier)</li>
        <li><code>assets/</code> — CSS/JS proprii</li>
        <li><code>api/mvp_kit_endpoint.php</code> — endpoint (copie în public/api la install sau proxy)</li>
    </ul>

    <button type="button" id="mvp-kit-ping" class="box rounded-md border bg-primary px-4 py-2 text-sm text-white">
        Test ping JS
    </button>
    <p id="mvp-kit-out" class="text-sm mt-3 opacity-70"></p>
</div>

<script src="<?= htmlspecialchars($jsUrl, ENT_QUOTES, 'UTF-8') ?>"></script>
