<?php

declare(strict_types=1);

namespace Besoiu\Modules\MvpKit;

/**
 * Serviciu propriu al modulului — NU pune asta în admin/src/Services/.
 * Namespace: Besoiu\Modules\{StudlyId}\…
 * Autoload: ModuleRegistry → modules/{Folder}/src/
 */
final class MvpKitService
{
    public function status(): array
    {
        return [
            'module' => 'mvp_kit',
            'ok' => true,
            'message' => 'Serviciul din pachetul modulului răspunde.',
            'at' => date('c'),
        ];
    }

    public function greeting(string $name = 'operator'): string
    {
        $name = trim($name) !== '' ? trim($name) : 'operator';

        return 'Salut, ' . $name . ' — modulul MVP Kit e conectat la CORE.';
    }
}
