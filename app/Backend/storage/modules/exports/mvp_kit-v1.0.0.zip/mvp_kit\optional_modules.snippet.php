<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'mvp_kit' => array (
  'slugs' => 
  array (
    0 => 'mvp-kit',
  ),
  'paths' => 
  array (
    0 => '/admin/mvp-kit',
    1 => '/admin/public/mvp-kit',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'mvp_kit_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'mvp-kit',
  ),
  'folder' => 'MvpKit',
),
];
