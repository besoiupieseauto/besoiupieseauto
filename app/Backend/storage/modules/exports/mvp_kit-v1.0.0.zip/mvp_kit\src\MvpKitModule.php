<?php

declare(strict_types=1);

namespace Besoiu\Modules\MvpKit;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/**
 * Entry al modulului — boot la fiecare request Admin când modulul e activ.
 *
 * Aici înregistrezi: listeners, CRUD keys, legături soft la CORE (produse, comenzi…).
 * Nu pune logică grea aici — doar wiring.
 */
final class MvpKitModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }

        // Exemplu: poți verifica alt modul opțional
        // if ($context->hasModule('import')) { … }

        // Marker: modulul e booted — registry îl ține în allBooted()
        $context->registry();
    }

    public function install(): void
    {
        // Rulează migrări din module.json → migrations/*.sql (idempotent)
    }

    public function uninstall(): void
    {
        // Dezactivează curat — nu șterge neapărat datele din BD
    }
}
