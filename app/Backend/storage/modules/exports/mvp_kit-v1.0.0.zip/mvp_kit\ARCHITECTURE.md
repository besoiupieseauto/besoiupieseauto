# Cum construiești un modul = mini-MVP conectat la CORE

## Ideea

```
CORE (OS)                    MODUL (HDD / plugin)
─────────────────            ────────────────────────────
auth, router, produse   ←→   modules/MyFeature/
comenzi, settings            ├── module.json
users, dashboard             ├── src/          ← clase PHP
                             ├── pages/        ← UI
                             ├── assets/       ← CSS/JS
                             ├── api/          ← endpoint-uri
                             └── migrations/   ← SQL
```

Modulul **nu** e un switch pe cod din `admin/src/`.
Modulul **este** un pachet separat pe care îl pui în proiect și se conectează la CORE.

## Structură obligatorie

```
MyFeature/
  module.json                 ← contract (id, entry, nav, provides)
  src/
    MyFeatureModule.php       ← entry (extends AbstractModule)
    MyFeatureService.php      ← logică (opțional)
  pages/
    index.php                 ← UI principal (slug din nav)
  assets/                     ← CSS/JS (opțional)
  api/                        ← endpoint-uri (opțional)
  migrations/                 ← SQL (opțional)
```

## Pași

1. Copiază acest folder (`mvp_kit`) și redenumește `id` / namespace / foldere.
2. Schimbă `module.json` (`id`, `name`, `nav`, `provides`, `entry`).
3. Namespace clase: `Besoiu\Modules\{StudlyId}\` (ex. `my_feature` → `MyFeature`).
4. **Builtin:** mută în `admin/modules/{StudlyId}/` + entry în `optional_modules.php` (sau lasă `provides` din manifest).
5. **Extern:** ZIP pe folder → Setări → Module → Instalează.
6. Smoke: Activează → vezi nav + pagină; Oprește → dispar; CORE (produse) OK.

## Ce rămâne în CORE

Doar: Auth, Router, Produse, Furnizori, Categorii, Comenzi, Settings, Dashboard, Users, Alerts.

Orice feature nou = **modul nou** cu folder propriu.
