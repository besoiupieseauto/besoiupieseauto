<?php

/**
 * Endpoint API al modulului.
 *
 * La instalare ZIP: copiază acest fișier în admin/public/api/mvp_kit_endpoint.php
 * SAU servește-l prin proxy (viitor). ModuleGate blochează scriptul dacă modulul e oprit.
 *
 * Exemplu (după copiere în public/api/):
 *   POST /admin/public/api/mvp_kit_endpoint.php
 */

declare(strict_types=1);

// Când e în public/api/, bootstrap-ul Admin e disponibil:
// require_once __DIR__ . '/_autoload.php';
// use Besoiu\Core\Bootstrap\ApiBootstrap;
// use Besoiu\Modules\MvpKit\MvpKitService;
// ApiBootstrap::bootJsonApi();
// …
// echo json_encode((new MvpKitService())->status());

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'success' => true,
    'message' => 'Stub API din pachetul modulului. Copiază în public/api/ la deploy.',
    'module' => 'mvp_kit',
], JSON_UNESCAPED_UNICODE);
