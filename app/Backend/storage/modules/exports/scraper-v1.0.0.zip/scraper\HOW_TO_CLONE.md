# Cum clonezi acest modul

1. Dezarhivează ZIP-ul.
2. Redenumește folderul (ex. `my_feature`) și schimbă în `module.json`:
   - `id` — doar `a-z`, `0-9`, `_` (ex. `my_feature`)
   - `name`, `description`, `nav[].id/href`, `provides.slugs/paths`
3. Pentru modul **builtin** (în repo):
   - mută folderul în `admin/modules/{StudlyId}/`
   - adaugă entry din `optional_modules.snippet.php` în `admin/config/optional_modules.php`
   - înconjoară linkurile din `nav.php` cu `ModuleGate::enabled('id')`
   - pune `"id": true` în `storage/modules/state.json`
4. Pentru modul **extern**:
   - ziuează folderul (cu `module.json` în rădăcină) într-un ZIP
   - Setări → Module → **Instalează modul**
5. Smoke: Oprește modulul → 0 rute/nav/API; CORE (produse, comenzi) OK.

Vezi și: `admin/modules/PACKAGING.md`