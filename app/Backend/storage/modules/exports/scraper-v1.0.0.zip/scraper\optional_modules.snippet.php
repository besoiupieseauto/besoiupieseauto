<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'scraper' => array (
  'slugs' => 
  array (
    0 => 'scraper',
  ),
  'paths' => 
  array (
    0 => '/admin/scraper',
    1 => '/admin/public/scraper',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'scraper_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'scraper',
  ),
  'folder' => 'Scraper',
),
];
