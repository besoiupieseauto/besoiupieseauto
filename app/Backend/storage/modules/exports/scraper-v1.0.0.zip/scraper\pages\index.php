<?php
declare(strict_types=1);
?>
<div class="box p-6" style="max-width:720px">
    <h1 class="text-xl font-semibold mb-2">Scraping</h1>
    <p class="text-sm opacity-80 mb-4">
        Pagină stub pentru modulul <code>scraper</code>. Înlocuiește cu UI-ul tău.
        La unplug din Setări → Module, ruta și meniul dispar.
    </p>
</div>
