<?php

declare(strict_types=1);

namespace Besoiu\Modules\Import;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/** Entry MVP — Import produse se conectează la CORE aici. */
final class ImportModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }
        $context->registry();
    }
}
