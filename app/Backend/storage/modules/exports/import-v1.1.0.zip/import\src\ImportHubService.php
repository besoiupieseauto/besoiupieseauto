<?php

declare(strict_types=1);

namespace Besoiu\Modules\Import;

/** Serviciu hub al modulului Import produse (logică în pachet). */
final class ImportHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        return [
            'module' => 'import',
            'name' => 'Import produse',
            'version' => '1.1.0',
            'ok' => true,
            'package' => ['src' => true, 'pages' => true, 'assets' => true, 'api' => true],
            'features' => array (
  0 => 
  array (
    'id' => 'import',
    'label' => 'Import CSV / Excel',
    'href' => '/admin/import',
    'desc' => 'Upload și mapare liste furnizor',
  ),
  1 => 
  array (
    'id' => 'importreview',
    'label' => 'Coadă import',
    'href' => '/admin/importreview',
    'desc' => 'Review conflicte și publish',
  ),
),
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf('%s v%s — %d zone · pachet MVP OK', $d['name'], $d['version'], count($d['features']));
    }
}
