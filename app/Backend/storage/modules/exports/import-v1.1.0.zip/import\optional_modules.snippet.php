<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'import' => array (
  'slugs' => 
  array (
    0 => 'import-system',
    1 => 'import',
    2 => 'importreview',
    3 => 'importproduse',
  ),
  'paths' => 
  array (
    0 => '/admin/import-system',
    1 => '/admin/public/import-system',
    2 => '/admin/import',
    3 => '/admin/public/import',
    4 => '/admin/importreview',
    5 => '/admin/public/importreview',
    6 => '/admin/importproduse',
    7 => '/admin/public/importproduse',
    8 => '/admin/public/bovsoft-import',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'import_endpoint.php',
    1 => 'import_action_endpoint.php',
    2 => 'supplier_sync_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'import-system',
    1 => 'import',
    2 => 'importreview',
  ),
  'folder' => 'Import',
),
];
