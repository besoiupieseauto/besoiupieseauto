(function () {
  var btn = document.getElementById('import-mod-ping');
  var out = document.getElementById('import-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Import/assets — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
