<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'success' => true,
    'module' => 'ai',
    'endpoint' => 'bots_endpoint',
    'message' => 'Stub din pachet. Producție: /admin/public/api/bots_endpoint.php',
], JSON_UNESCAPED_UNICODE);
