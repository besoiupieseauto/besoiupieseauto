<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'success' => true,
    'module' => 'ai',
    'endpoint' => 'ai_tokens_endpoint',
    'message' => 'Stub din pachet. Producție: /admin/public/api/ai_tokens_endpoint.php',
], JSON_UNESCAPED_UNICODE);
