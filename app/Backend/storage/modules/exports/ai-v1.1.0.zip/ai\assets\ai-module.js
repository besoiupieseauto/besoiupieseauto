(function () {
  var btn = document.getElementById('ai-mod-ping');
  var out = document.getElementById('ai-mod-out');
  if (!btn || !out) return;
  btn.addEventListener('click', function () {
    out.textContent = 'JS din modules/Ai/assets/ai-module.js — OK · ' + new Date().toLocaleTimeString('ro-RO');
  });
})();
