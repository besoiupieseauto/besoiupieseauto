<?php

declare(strict_types=1);

/**
 * Bridge pagină AI Agent — UI detaliat încă din Templates (migrare treptată).
 * Fișierul trăiește în pachetul modulului; resolver-ul îl găsește aici.
 */
$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/ai-agent/ai-agent.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}

echo '<div class="box p-6"><p>AI Agent — template legacy lipsă. Folosește hub-ul <a href="/admin/ai-system">/admin/ai-system</a>.</p></div>';
