<?php

declare(strict_types=1);

namespace Besoiu\Modules\Ai;

/**
 * Serviciu propriu al modulului AI (logică în pachet, nu în admin/src/Services/).
 */
final class AiHubService
{
    /** @return array<string, mixed> */
    public function dashboard(): array
    {
        $features = [
            [
                'id' => 'ai-agent',
                'label' => 'AI Agent',
                'href' => '/admin/ai-agent',
                'desc' => 'Supervizor, template-uri, Ollama / hub LLM',
            ],
            [
                'id' => 'ai-tokens',
                'label' => 'AI Tokens',
                'href' => '/admin/ai-tokens',
                'desc' => 'Consum tokeni, praguri, alerte buget',
            ],
            [
                'id' => 'bots',
                'label' => 'Roboți AI',
                'href' => '/admin/bots',
                'desc' => 'WhatsApp, Facebook, BaseLinker, monitor',
            ],
        ];

        return [
            'module' => 'ai',
            'name' => 'AI System',
            'version' => '1.1.0',
            'ok' => true,
            'package' => [
                'src' => true,
                'pages' => true,
                'assets' => true,
                'api' => true,
            ],
            'features' => $features,
            'core_bridge' => [
                'note' => 'UI detaliat (agent/tokens/bots) poate încă apela Services din CORE până la migrare completă.',
                'services_hint' => ['AiAgentTemplates', 'AiContextAgentService', 'BotsService'],
            ],
            'at' => date('c'),
        ];
    }

    public function healthLine(): string
    {
        $d = $this->dashboard();

        return sprintf(
            'AI System v%s — %d zone · pachet MVP OK',
            (string) ($d['version'] ?? '?'),
            count($d['features'] ?? [])
        );
    }
}
