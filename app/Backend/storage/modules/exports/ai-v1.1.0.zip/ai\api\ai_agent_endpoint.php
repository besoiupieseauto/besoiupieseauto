<?php

/**
 * Endpoint din pachetul modulului AI.
 * Live: admin/public/api/ai_agent_endpoint.php (CORE bridge până la mutare completă).
 * Acest fișier documentează contractul API al modulului.
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

echo json_encode([
    'success' => true,
    'module' => 'ai',
    'endpoint' => 'ai_agent_endpoint',
    'message' => 'Stub din pachet. Producție: /admin/public/api/ai_agent_endpoint.php',
    'hint' => 'ModuleGate blochează ai_agent_endpoint.php când modulul ai e oprit.',
], JSON_UNESCAPED_UNICODE);
