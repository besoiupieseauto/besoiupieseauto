<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'ai' => array (
  'slugs' => 
  array (
    0 => 'ai-system',
    1 => 'ai-agent',
    2 => 'ai-tokens',
    3 => 'bots',
    4 => 'bots-pieseauto',
    5 => 'bots-whatsapp',
    6 => 'bots-facebook',
    7 => 'bots-baselinker',
    8 => 'bots-monitor',
    9 => 'bots-registry',
  ),
  'paths' => 
  array (
    0 => '/admin/ai-system',
    1 => '/admin/ai-agent',
    2 => '/admin/ai-tokens',
    3 => '/admin/bots',
    4 => '/admin/public/ai-system',
    5 => '/admin/public/ai-agent',
    6 => '/admin/public/ai-tokens',
    7 => '/admin/public/bots',
    8 => '/admin/public/bots-pieseauto',
    9 => '/admin/public/bots-whatsapp',
    10 => '/admin/public/bots-facebook',
    11 => '/admin/public/bots-baselinker',
    12 => '/admin/public/bots-monitor',
    13 => '/admin/public/bots-registry',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'ai_agent_endpoint.php',
    1 => 'ai_tokens_endpoint.php',
    2 => 'bots_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'ai-system',
    1 => 'ai-agent',
    2 => 'ai-tokens',
    3 => 'bots',
  ),
  'folder' => 'Ai',
),
];
