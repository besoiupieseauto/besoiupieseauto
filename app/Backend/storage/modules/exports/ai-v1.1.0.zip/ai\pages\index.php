<?php

declare(strict_types=1);

/**
 * Hub MVP al modulului AI — UI din pachet (nu din Templates legacy).
 */

use Besoiu\Modules\Ai\AiHubService;

$hub = new AiHubService();
$data = $hub->dashboard();
$css = '/admin/modules/Ai/assets/ai-module.css';
$js = '/admin/modules/Ai/assets/ai-module.js';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($css, ENT_QUOTES, 'UTF-8') ?>">

<div class="box p-6 ai-mod" style="max-width:960px">
    <header class="ai-mod__head mb-4">
        <h1 class="text-xl font-semibold">AI System</h1>
        <p class="text-sm opacity-80 mt-1"><?= htmlspecialchars($hub->healthLine(), ENT_QUOTES, 'UTF-8') ?></p>
    </header>

    <div class="ai-mod__grid">
        <?php foreach ($data['features'] as $f): ?>
            <a class="ai-mod__card" href="<?= htmlspecialchars((string) $f['href'], ENT_QUOTES, 'UTF-8') ?>">
                <strong><?= htmlspecialchars((string) $f['label'], ENT_QUOTES, 'UTF-8') ?></strong>
                <span><?= htmlspecialchars((string) $f['desc'], ENT_QUOTES, 'UTF-8') ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <section class="ai-mod__meta mt-5 text-xs opacity-70">
        <p>Pachet: <code>modules/Ai/</code> — <code>src/</code> · <code>pages/</code> · <code>assets/</code> · <code>api/</code></p>
        <pre class="mt-2 overflow-auto"><?= htmlspecialchars(json_encode($data['package'], JSON_PRETTY_PRINT), ENT_QUOTES, 'UTF-8') ?></pre>
    </section>

    <button type="button" id="ai-mod-ping" class="box rounded-md border bg-primary px-4 py-2 text-sm text-white mt-4">
        Test assets JS
    </button>
    <p id="ai-mod-out" class="text-sm mt-2 opacity-70"></p>
</div>

<script src="<?= htmlspecialchars($js, ENT_QUOTES, 'UTF-8') ?>"></script>
