<?php

declare(strict_types=1);

namespace Besoiu\Modules\Ai;

use Besoiu\Core\Module\AbstractModule;
use Besoiu\Core\Module\ModuleContext;

/**
 * Entry MVP — modulul AI se conectează la CORE aici (nu trăiește în admin/src/).
 */
final class AiModule extends AbstractModule
{
    public function boot(ModuleContext $context): void
    {
        if (!$context->isCoreAvailable()) {
            return;
        }

        // Wiring soft: hub-ul poate citi status din CORE services dacă există
        $context->registry();
    }

    public function install(): void
    {
        // Viitor: migrări din migrations/
    }

    public function uninstall(): void
    {
        // Dezactivare curată — datele rămân
    }
}
