# AI System — mini-MVP în pachet

```
modules/Ai/
  module.json
  src/
    AiModule.php       ← entry + boot (conectare CORE)
    AiHubService.php   ← logică hub
  pages/
    index.php          ← hub /admin/ai-system
    ai-agent.php       ← bridge → UI agent
    ai-tokens.php      ← bridge → UI tokens
    bots.php           ← bridge → UI roboți
  assets/
    ai-module.css
    ai-module.js
  api/
    ai_agent_endpoint.php
    ai_tokens_endpoint.php
    bots_endpoint.php
```

CORE rămâne: auth, produse, comenzi. Acest folder = feature AI ca HDD/plugin.
