<?php

declare(strict_types=1);

$legacy = dirname(__DIR__, 3) . '/Templates/admin/pages/bots/bots.php';
if (is_file($legacy)) {
    require $legacy;
    return;
}

echo '<div class="box p-6"><p>Roboți AI — template legacy lipsă. Hub: <a href="/admin/ai-system">/admin/ai-system</a>.</p></div>';
