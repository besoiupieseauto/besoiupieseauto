<?php

// Fragment pentru admin/config/optional_modules.php
// Copiază cheia de mai jos în array-ul returnat.

return [
    'ai' => array (
  'slugs' => 
  array (
    0 => 'ai-agent',
    1 => 'ai-tokens',
    2 => 'bots',
    3 => 'bots-pieseauto',
    4 => 'bots-whatsapp',
    5 => 'bots-facebook',
    6 => 'bots-baselinker',
    7 => 'bots-monitor',
    8 => 'bots-registry',
  ),
  'paths' => 
  array (
    0 => '/admin/ai-agent',
    1 => '/admin/ai-tokens',
    2 => '/admin/bots',
    3 => '/admin/public/ai-agent',
    4 => '/admin/public/ai-tokens',
    5 => '/admin/public/bots',
    6 => '/admin/public/bots-pieseauto',
    7 => '/admin/public/bots-whatsapp',
    8 => '/admin/public/bots-facebook',
    9 => '/admin/public/bots-baselinker',
    10 => '/admin/public/bots-monitor',
    11 => '/admin/public/bots-registry',
  ),
  'crud_key' => NULL,
  'api_scripts' => 
  array (
    0 => 'ai_agent_endpoint.php',
    1 => 'ai_tokens_endpoint.php',
    2 => 'bots_endpoint.php',
  ),
  'quick_actions' => 
  array (
    0 => 'ai-agent',
    1 => 'ai-tokens',
    2 => 'bots',
  ),
  'folder' => 'Ai',
),
];
