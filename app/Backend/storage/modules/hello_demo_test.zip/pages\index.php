<?php
declare(strict_types=1);
?>
<div class="box p-6" style="max-width:720px">
    <h1 class="text-xl font-semibold mb-2">Hello Demo</h1>
    <p class="text-sm opacity-80 mb-4">
        Modul extern instalat corect. Înlocuiește acest fișier (<code>pages/index.php</code>)
        cu UI-ul tău. La unplug din Setări → Module, ruta și meniul dispar.
    </p>
    <ul class="text-sm list-disc pl-5 space-y-1 opacity-70">
        <li>Spec: <code>admin/modules/PACKAGING.md</code></li>
        <li>Manifest: <code>module.json</code></li>
        <li>Gate: <code>ModuleGate::enabled('hello_demo')</code></li>
    </ul>
</div>
